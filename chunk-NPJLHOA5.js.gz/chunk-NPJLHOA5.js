import{a,b,c,d,e,g as f}from"./chunk-X5YLR3NI.js";import"./chunk-ODN5LVDJ.js";f();export{c as Headers,d as Request,e as Response,b as default,a as fetch};
